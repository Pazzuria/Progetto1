let people = [];

function aggiungiPersona() {
    let nome = document.getElementById("nome").value;
    let cognome = document.getElementById("cognome").value;
    let email = document.getElementById("email").value;
    let dob = document.getElementById("dob").value;
    let telefono = document.getElementById("telefono").value;
    let paese = document.getElementById("paese").value;
    let provincia = document.getElementById("provincia").value;

    
    if (nome === "" || cognome === "" || email === "" || dob === "" || telefono === "" || paese === "" || provincia === "") {
        alert("Tutti i campi devono essere compilati");
        return;
    }

   

    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Inserisci un'email valida");
        return;
    }

  
    let telefonoRegex = /^[0-9]{10}$/;
    if (!telefonoRegex.test(telefono)) {
        alert("Inserisci un numero di telefono valido (10 cifre)");
        return;
    }


    let persona = {
        nome: nome,
        cognome: cognome,
        email: email,
        dob: dob,
        telefono: telefono,
        paese: paese,
        provincia: provincia
    };

    people.push(persona);
    aggiornaTabella();

    document.getElementById("formPersona").reset();
}

function aggiornaTabella() {
    let elencoPersone = document.getElementById("elencoPersone");
    elencoPersone.innerHTML = "";

    people.forEach((persona, index) => {
        let riga = document.createElement("tr");

        riga.innerHTML = `
            <td>${persona.nome}</td>
            <td>${persona.cognome}</td>
            <td>${persona.email}</td>
            <td>${persona.dob}</td>
            <td>${persona.telefono}</td>
            <td>${persona.paese}</td>
            <td>${persona.provincia}</td>
            <td><button class="rimuovi" onclick="rimuoviPersona(${index})">Rimuovi</button></td>
        `;

        elencoPersone.appendChild(riga);
    });
}

function rimuoviPersona(index) {
    people.splice(index, 1);
    aggiornaTabella();
}
